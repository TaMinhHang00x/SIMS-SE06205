﻿using System.ComponentModel.DataAnnotations;
namespace SIMS_SE06205.Models
{
    public class StudentModel
    {
        public List<StudentViewModel> StudentsList { get; set; }
    }


    public class StudentViewModel
    {
        [Key]
        public string? Id { get; set; }

        [Required(ErrorMessage = "Student's Code can be not empty")]
        public string StudentCode { get; set; }

        [Required(ErrorMessage = "Student's Name can be not empty")]
        public string? StudentName { get; set; }

        [Required(ErrorMessage = "Student's Birthday can be not empty")]
        public string? Birthday { get; set; }
        public string? Address { get; set; }
        public string? Gender { get; set; }

        [Required(ErrorMessage = "Student's Phone can be not empty")]
        public string? Phone { get; set; }
    }
}
