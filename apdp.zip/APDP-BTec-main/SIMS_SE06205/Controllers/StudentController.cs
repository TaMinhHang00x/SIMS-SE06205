﻿using Microsoft.AspNetCore.Mvc;
using SIMS_SE06205.Models;
using Newtonsoft.Json;

namespace SIMS_SE06205.Controllers
{
    public class StudentController : Controller
    {
        private string filePathStudent = @"C:\Csharp\data-sims\\data-student.json";

        [HttpGet]
        public IActionResult Index()
        {
            string dataJson = System.IO.File.ReadAllText(filePathStudent);
            StudentModel studentModel = new StudentModel();
            studentModel.StudentsList = new List<StudentViewModel>();

            // kiem tra username va password co ton tai trong dataJson hay khong ?
            var student = JsonConvert.DeserializeObject<List<StudentViewModel>>(dataJson);
            var dataStudent = (from s in student select s).ToList();
            foreach (var item in dataStudent)
            {
                studentModel.StudentsList.Add(new StudentViewModel
                {
                    Id = item.Id,
                    StudentCode = item.StudentCode,
                    StudentName = item.StudentName,
                    Birthday = item.Birthday,
                    Address = item.Address,
                    Gender = item.Gender,
                    Phone = item.Phone,
                });
            }
            return View(studentModel);
        }

        [HttpGet]
        public IActionResult Add()
        {

            StudentViewModel student = new StudentViewModel();
            return View(student);
        }

        [HttpPost]
        public IActionResult Add(StudentViewModel studentViewModel)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    string dataJson = System.IO.File.ReadAllText(filePathStudent);
                    var students = JsonConvert.DeserializeObject<List<StudentViewModel>>(dataJson);
                    int maxId = 0;
                    if (students != null)
                    {
                        maxId = int.Parse((from s in students
                                           select s.Id).Max()) + 1;
                    }
                    string idIncrement = maxId.ToString();

                    students.Add(new StudentViewModel
                    {
                        Id = idIncrement,
                        StudentCode = studentViewModel.StudentCode,
                        StudentName = studentViewModel.StudentName,
                        Birthday = studentViewModel.Birthday,
                        Address = studentViewModel.Address,
                        Gender = studentViewModel.Gender,
                        Phone = studentViewModel.Phone,
                    });
                    var dtJson = JsonConvert.SerializeObject(students, Formatting.Indented);
                    System.IO.File.WriteAllText(filePathStudent, dtJson);
                    TempData["saveStatus"] = true;
                }
                catch
                {
                    TempData["saveStatus"] = false;
                }
                return RedirectToAction(nameof(CourseController.Index), "Student");
            }
            return View(studentViewModel);
        }

        [HttpGet]
        public IActionResult Delete(int id = 0)
        {
            try
            {
                string dataJson = System.IO.File.ReadAllText(filePathStudent);
                var students = JsonConvert.DeserializeObject<List<StudentViewModel>>(dataJson);
                var itemToDelete = students.Find(item => item.Id == id.ToString());
                if (itemToDelete != null)
                {
                    students.Remove(itemToDelete);
                    string deletedJson = JsonConvert.SerializeObject(students, Formatting.Indented);
                    System.IO.File.WriteAllText(filePathStudent, deletedJson);
                    TempData["DeleteStatus"] = true;
                }
                else
                {
                    TempData["DeleteStatus"] = false;
                }
            }
            catch
            {
                TempData["DeleteStatus"] = false;
            }
            return RedirectToAction(nameof(StudentController.Index), "Student");
        }

        [HttpGet]
        public IActionResult Update(int id = 0)
        {
            string dataJson = System.IO.File.ReadAllText(filePathStudent);
            var students = JsonConvert.DeserializeObject<List<StudentViewModel>>(dataJson);
            var itemStudent = students.Find(item => item.Id == id.ToString());

            StudentViewModel studentModel = new StudentViewModel();

            if (itemStudent != null)
            {
                studentModel.Id = itemStudent.Id;
                studentModel.StudentCode = itemStudent.StudentCode;
                studentModel.StudentName = itemStudent.StudentName;
                studentModel.Birthday = itemStudent.Birthday;
                studentModel.Address = itemStudent.Address;
                studentModel.Gender = itemStudent.Gender;
                studentModel.Phone = itemStudent.Phone;
            }

            return View(studentModel);
        }

        [HttpPost]
        public IActionResult Update(StudentViewModel studentModel)
        {
            try
            {
                string dataJson = System.IO.File.ReadAllText(filePathStudent);
                var students = JsonConvert.DeserializeObject<List<StudentViewModel>>(dataJson);
                var itemStudent = students.Find(item => item.Id == studentModel.Id.ToString());

                if (itemStudent != null)
                {
                    itemStudent.StudentCode = studentModel.StudentCode;
                    itemStudent.StudentName = studentModel.StudentName;
                    itemStudent.Birthday = studentModel.Birthday;
                    itemStudent.Address = studentModel.Address;
                    itemStudent.Gender = studentModel.Gender;
                    itemStudent.Phone = studentModel.Phone;
                    string updateJson = JsonConvert.SerializeObject(students, Formatting.Indented);
                    System.IO.File.WriteAllText(filePathStudent, updateJson);
                    TempData["UpdateStatus"] = true;
                }
                else
                {
                    TempData["UpdateStatus"] = false;
                }
            }
            catch (Exception ex)
            {
                TempData["UpdateStatus"] = false;
            }
            return RedirectToAction(nameof(StudentController.Index), "Student");
        }
    }
}
